package nicks;

public class Main {
    public static void main(String[] args) {
        TimeFutebol futebol = new TimeFutebol("Palmeiras", 0);
        TimeBasquete basquete = new TimeBasquete("Lakers");

        futebol.venceu();
        futebol.empatou();
        futebol.perdeu();

        basquete.venceu();
        basquete.venceu();

        System.out.println("Situação dos Times");
        futebol.imprimirSituacao();
        System.out.println();
        basquete.imprimirSituacao();
    }
}