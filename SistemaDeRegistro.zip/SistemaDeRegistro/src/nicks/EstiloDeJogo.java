package nicks;

public interface EstiloDeJogo {
String estilo();
}
