package nicks;

public class TimeBasquete extends EquipeEsportiva implements EstiloDeJogo {

    public TimeBasquete(String nome) {
        super(nome);
    }

@Override
    public String estilo() {
        return "Ofensivo e ágil";
    }

@Override
public void imprimirSituacao() {
	System.out.println("Time de Basquete: " + nome);
	System.out.println("Jogos realizados: " + jogosRealizados);
	System.out.println("Pontos ganhos: " + pontosGanhos);
	System.out.println("Estilo de jogo: " + estilo());
    }
}
