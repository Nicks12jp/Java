package nicks;

//classe abstrata
public abstract class EquipeEsportiva {
String nome;
int jogosRealizados;
int pontosGanhos;

//metodo construtor
public EquipeEsportiva(String nome) {
	this.nome = nome;
	this.jogosRealizados = 0;
	this.pontosGanhos = 0;
}
//gets
public String getNome() {
	return nome;
}

public int getPontosGanhos() {
	return pontosGanhos;
}

//metodo registrar pontos
public void registrarJogo(int pontos) {
	jogosRealizados++;
	pontosGanhos += pontos;
}

//metodos de vitoria, derrota e empate
public void venceu() {
	registrarJogo(3);
}

public void empatou() {
	registrarJogo(1);
}

public void perdeu() {
	registrarJogo(0);
}
//metodo exibir
public abstract void imprimirSituacao();
}
