package nicks;

public class TimeFutebol extends EquipeEsportiva implements EstiloDeJogo{
	private int estiloDeJogo;

	public TimeFutebol(String nome, int estiloDeJogo) {
		super(nome);
		this.estiloDeJogo = estiloDeJogo;
	}
	
@Override
public String estilo() {
	if (estiloDeJogo == 0) {
		return "Retranqueiro";
	} else if (estiloDeJogo == 1) {
		return "Ofensivo";
	} else {
		return "Desconhecido";
	}
}
@Override
public void imprimirSituacao() {
	System.out.println("Time de Futebol: " + nome);
	System.out.println("Jogos realizados: " + jogosRealizados);
	System.out.println("Pontos ganhos: " + pontosGanhos);
	System.out.println("Estilo de jogo: " + estilo());
    }
}
