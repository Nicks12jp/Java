package nicks;

public interface Voo {
public String tipoDeVoo();
}
