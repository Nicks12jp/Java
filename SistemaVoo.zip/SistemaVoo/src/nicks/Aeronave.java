package nicks;

//classe abstrada
public abstract class Aeronave {
	protected String modelo;
	protected int capacidade;

//metodo construtor
public Aeronave(String modelo, int capacidade) {
	this.modelo = modelo;
	this.capacidade = capacidade;
}

//get
public String getModelo() {
	return modelo;
}

//set
public void setModelo(String modelo) {
	this.modelo = modelo;
}
//metodo exibir
public abstract void exibirInformacoes();
}