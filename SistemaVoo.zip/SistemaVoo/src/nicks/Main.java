package nicks;

public class Main {
	public static void main(String [] args) {
		AviaoComercial comercial = new AviaoComercial("Boeing 737", 180);
		
		AviaoCarga carga = new AviaoCarga("Cargolux 747", 100);
		
		System.out.println("Avião Comercial");
		comercial.exibirInformacoes();
		
		System.out.println("\nAvião de Carga");
		carga.exibirInformacoes();
	}
}
