package nicks;

public class AviaoComercial extends Aeronave implements Voo{
public AviaoComercial(String modelo, int capacidade) {
	super(modelo, capacidade);
}

@Override
public String tipoDeVoo() {
	return "Transporte de Passageiros";
}

@Override
public void exibirInformacoes() {
	System.out.println("Modelo: " + modelo);
	System.out.println("Capacidade: " + capacidade);
	System.out.println("Tipo de Voo: " + tipoDeVoo());
}
}
